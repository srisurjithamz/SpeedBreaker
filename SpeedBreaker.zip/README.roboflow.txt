
SpeedBreaker - v2 2021-08-21 10:48pm
==============================

This dataset was exported via roboflow.ai on August 21, 2021 at 5:19 PM GMT

It includes 1121 images.
Breaker are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random shear of between -43° to +43° horizontally and -25° to +25° vertically


