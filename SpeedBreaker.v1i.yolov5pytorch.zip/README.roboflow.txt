
SpeedBreaker - v1 2021-06-25 5:48pm
==============================

This dataset was exported via roboflow.ai on June 25, 2021 at 12:20 PM GMT

It includes 467 images.
Breaker are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 300x300 (Stretch)

No image augmentation techniques were applied.


